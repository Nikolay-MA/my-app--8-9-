// sfc
import './css1.css';
const AboutMe = () => {
  return (<>
    <p>1</p>
  </>
  );
}

export default AboutMe;