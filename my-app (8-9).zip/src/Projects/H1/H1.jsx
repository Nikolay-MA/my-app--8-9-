
export default function H1() {
  return (
    <p>Проект № 1</p>
  )
}